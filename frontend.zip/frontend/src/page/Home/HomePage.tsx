import TopBar from '@/components/TopBar'
import React from 'react'

function HomePage() {
  return (
    <div>
      <TopBar/>
    </div>
  )
}

export default HomePage
