import React from 'react'

function ChatPage() {
  return (
    <div>
      chatpage
    </div>
  )
}

export default ChatPage
